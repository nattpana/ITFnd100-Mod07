# ------------------------------------------------- #
# Title: Demo Fruit_Store using Pickling and Error Handing within Python.
# Description: # Demo adding fruits name into fruit stores by using
#                Pickle in program and using error expression to help catch the error
# ChangeLog: (Who, When, What)
# <Example Natta Panapornsirikun,06/01/2023,Created Script>
# ------------------------------------------------- #

# Function to store fruit information
# Import pickle
# Import pickle
import pickle

# Function to store fruit information
def store_fruit_info():
    while True:
        print_all_fruits()  # Print all fruits
        name = input("Enter fruit name (type 'exit' to stop): ")
        if name.lower() == "exit":
            break
        if any(char.isdigit() for char in name):
            raise ValueError("Invalid fruit name. Please enter a valid name without numbers.")
        fruit_info = {"fruit_name": name}
        try:
            # Pickle the fruit information and save it to a file
            with open("fruit_info.pickle", "ab") as file:
                pickle.dump(fruit_info, file)
            print("Fruit information stored successfully!")
        except IOError as e:
            print("Error occurred while storing fruit information:", e)
        except ValueError as ve:
            print(ve)

# Function to retrieve fruit information
def retrieve_fruit_info():
    try:
        # Unpickle and return all fruit information from the file
        with open("fruit_info.pickle", "rb") as file:
            fruits = []
            while True:
                try:
                    fruit_info = pickle.load(file)
                    fruits.append(fruit_info["fruit_name"])
                except EOFError:
                    break
        return fruits
    except IOError as e:
        print("Error occurred while retrieving fruit information:", e)
    except pickle.UnpicklingError as e:
        print("Error occurred while unpickling fruit information:", e)

# Function to print all fruits
def print_all_fruits():
    fruits = retrieve_fruit_info()
    print("All fruits:", fruits)

# Clear existing fruit information
def clear_fruit_info():
    try:
        with open("fruit_info.pickle", "wb") as file:
            file.truncate(0)
        print("Fruit information cleared successfully!")
    except IOError as e:
        print("Error occurred while clearing fruit information:", e)

# Retrieve fruit information
fruits = retrieve_fruit_info()

# Display fruit information
print_all_fruits()

# Prompt user for action
choice = input("Enter 'clear' to clear fruit list, or any other key to enter new fruit: ")

if choice.lower() == "clear":
    clear_fruit_info()

# Store and retrieve fruit information
while True:
    store_fruit_info()






